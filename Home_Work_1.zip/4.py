def to_roman(n):
    #   Код функции to_roman(n) переводит целое число n в римскую систему счисления
    roman_nums = {100: 'C', 90: 'XC', 50: 'L', 40: 'XL', 10: 'X', 9: 'IX', 5: 'V', 4: 'IV', 1: 'I'}
    result = ''
    for num, roman in roman_nums.items():
        # В цикле for num, roman in roman_nums.items(): проходятся все пары ключ-значение из словаря roman_nums.
        while n >= num:
            #   С помощью цикла while n >= num: происходит проверка, сколько раз можно вычесть из n текущее арабское число num.
            result += roman
            n -= num
    return result
m = int(input())
print(to_roman(m))